(() => {
  const stage = document.querySelector('.fork-stage');
  const section = document.querySelector('.fork-section');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const year = document.querySelector('#year');
  if (year) year.textContent = new Date().getFullYear();

  if (!stage || !section || reduced.matches) return;

  let frame = 0;
  const update = () => {
    frame = 0;
    const rect = section.getBoundingClientRect();
    const travel = Math.max(1, rect.height - window.innerHeight);
    const progress = Math.max(0, Math.min(1, -rect.top / travel));
    const mobile = window.matchMedia('(max-width: 760px)').matches;
    stage.style.setProperty('--p', progress.toFixed(4));
    stage.style.setProperty('--reveal-x', `${(mobile ? 104 : 106) * progress}%`);
    stage.style.setProperty('--reveal-y', `${(mobile ? 84 : 76) * progress}%`);
    stage.style.setProperty('--link-opacity', `${progress}`);
    stage.style.setProperty('--link-rise', `${(1 - progress) * 10}px`);
    stage.style.setProperty('--progress-width', `${progress * 100}%`);
    stage.style.setProperty('--branch-offset', `${(mobile ? 560 : 1200) * (1 - progress)}px`);
  };
  const requestUpdate = () => {
    if (!frame) frame = requestAnimationFrame(update);
  };

  window.addEventListener('scroll', requestUpdate, { passive: true });
  window.addEventListener('resize', requestUpdate, { passive: true });
  reduced.addEventListener?.('change', (event) => {
    if (event.matches) {
      window.removeEventListener('scroll', requestUpdate);
      window.removeEventListener('resize', requestUpdate);
      stage.style.removeProperty('--p');
      stage.style.removeProperty('--reveal-x');
      stage.style.removeProperty('--reveal-y');
      stage.style.removeProperty('--link-opacity');
      stage.style.removeProperty('--link-rise');
      stage.style.removeProperty('--progress-width');
      stage.style.removeProperty('--branch-offset');
    } else {
      window.addEventListener('scroll', requestUpdate, { passive: true });
      window.addEventListener('resize', requestUpdate, { passive: true });
      requestUpdate();
    }
  });
  requestUpdate();
})();
